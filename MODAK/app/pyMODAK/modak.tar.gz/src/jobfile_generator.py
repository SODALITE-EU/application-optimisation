import json
import os
from tuner import tuner
import logging

class jobfile_generator():

    def __init__(self, job_json_obj, batch_file:str, scheduler:str):
        logging.info("Initialising job file generator")
        self.scheduler = scheduler
        self.batch_file = batch_file
        self.job_json_obj = job_json_obj
        self.job_data = job_json_obj['job']['job_options']
        self.app_data = job_json_obj['job']['application']
        self.opt_data = job_json_obj['job']['optimisation']
        self.singularity_exec = 'singularity exec'
        self.current_dir = './'

        if job_json_obj['job'].get('target') is not None:
            if job_json_obj['job'].get('target').get('job_scheduler_type') is not None:
                scheduler = job_json_obj['job']['target']['job_scheduler_type']

        if scheduler == 'torque':
            self.__generate_torque_header(batch_file)
        elif scheduler == 'slurm':
            self.__generate_slurm_header(batch_file)

    # Based on https://kb.northwestern.edu/page.php?id=89454
    def __generate_torque_header(self, filename:str):
        logging.info("Generating torque header")
        self.scheduler = 'torque'
        self.batch_file = filename
        DIRECTIVE = '#PBS'
        f = open(filename, 'w')
        f.write(DIRECTIVE + ' -S ' + '/bin/bash')
        f.write('\n')
        f.write('## START OF HEADER ## ')
        f.write('\n')
        if "job_name" in self.job_data:
            f.write(DIRECTIVE + ' -N ' + self.job_data['job_name'])
            f.write('\n')
        if "account" in self.job_data:
            f.write(DIRECTIVE + ' -A ' + self.job_data['account'])
            f.write('\n')
        if "queue" in self.job_data:
            f.write(DIRECTIVE + ' -q ' + self.job_data['queue'])
            f.write('\n')
        if "wall_time_limit" in self.job_data:
            f.write(DIRECTIVE + ' -l walltime=' + self.job_data['wall_time_limit'])
            f.write('\n')
        if "node_count" in self.job_data:
            f.write(DIRECTIVE + ' -l nodes=' + str(self.job_data['node_count']))
            if "process_count_per_node" in self.job_data:
                f.write(':ppn=' + str(self.job_data['process_count_per_node']))
            if "request_gpus" in self.job_data:
                f.write(':gpus=' + str(self.job_data['request_gpus']))
                self.singularity_exec = self.singularity_exec + ' --nv '
            f.write('\n')
        if "core_count" in self.job_data:
            f.write(DIRECTIVE + ' -l procs=' + str(self.job_data['core_count']))
            f.write('\n')
        if "core_count_per_process" in self.job_data:
            pass
        if "memory_limit" in self.job_data:
            f.write(DIRECTIVE + ' -l mem=' + self.job_data['memory_limit'])
            f.write('\n')
        if "minimum_memory_per_processor" in self.job_data:
            f.write(DIRECTIVE + ' -l pmem=' + self.job_data['minimum_memory_per_processor'])
            f.write('\n')
        if "request_specific_nodes" in self.job_data:
            f.write(DIRECTIVE + ' -l nodes=' + self.job_data['request_specific_nodes'])
            f.write('\n')
        if "job_array" in self.job_data:
            f.write(DIRECTIVE + ' -t ' + self.job_data['job_array'])
            f.write('\n')
        if "standard_output_file" in self.job_data:
            f.write(DIRECTIVE + ' -o ' + self.job_data['standard_output_file'])
            f.write('\n')
        if "standard_error_file" in self.job_data:
            f.write(DIRECTIVE + ' -e ' + self.job_data['standard_error_file'])
            f.write('\n')
        if "combine_stdout_stderr" in self.job_data:
            f.write(DIRECTIVE + ' -j oe')
            f.write('\n')
        if "architecture_constraint" in self.job_data:
            f.write(DIRECTIVE + ' -l partition=' + self.job_data['architecture_constraint'])
            f.write('\n')
        if "copy_environment" in self.job_data:
            f.write(DIRECTIVE + ' -V ')
            f.write('\n')
        if "copy_environment_variable" in self.job_data:
            f.write(DIRECTIVE + ' -v ' + self.job_data['copy_environment_variable'])
            f.write('\n')
        if "job_dependency" in self.job_data:
            f.write(DIRECTIVE + ' -W ' + self.job_data['job_dependency'])
            f.write('\n')
        if "request_event_notification" in self.job_data:
            f.write(DIRECTIVE + ' -m ' + self.job_data['request_event_notification'])
            f.write('\n')
        if "email_address" in self.job_data:
            f.write(DIRECTIVE + ' -M ' + self.job_data['email_address'])
            f.write('\n')
        if "defer_job" in self.job_data:
            f.write(DIRECTIVE + ' -a ' + self.job_data['defer_job'])
            f.write('\n')
        if "node_exclusive" in self.job_data:
            f.write(DIRECTIVE + ' -l naccesspolicy=singlejob')
            f.write('\n')

        f.write('## END OF HEADER ## ')
        f.write('\n')
        f.write('cd $PBS_O_WORKDIR')
        f.write('\n')
        self.current_dir = '$PBS_O_WORKDIR/'
        f.write('export PATH=$PBS_O_WORKDIR:$PATH')
        f.write('\n')
        f.close()

    def __generate_slurm_header(self, filename:str):
        logging.info("Generating slurm header")
        self.scheduler = 'slurm'
        self.batch_file = filename
        DIRECTIVE = '#SBATCH'
        f = open(filename, 'w')
        f.write('#!/bin/bash')
        f.write('\n')
        f.write('## START OF HEADER ##')
        f.write('\n')
        if "job_name" in self.job_data:
            f.write(DIRECTIVE + ' -J ' + self.job_data['job_name'])
            f.write('\n')
        if "account" in self.job_data:
            f.write(DIRECTIVE + ' -A ' + self.job_data['account'])
            f.write('\n')
        if "queue" in self.job_data:
            f.write(DIRECTIVE + ' --partition=' + self.job_data['queue'])
            f.write('\n')
        if "wall_time_limit" in self.job_data:
            f.write(DIRECTIVE + ' --time=' + self.job_data['wall_time_limit'])
            f.write('\n')
        if "node_count" in self.job_data:
            f.write(DIRECTIVE + ' -N ' + str(self.job_data['node_count']))
            f.write('\n')
        if "core_count" in self.job_data:
            f.write(DIRECTIVE + ' -n ' + str(self.job_data['core_count']))
            f.write('\n')
        if "process_count_per_node" in self.job_data:
            f.write(DIRECTIVE + ' --ntasks-per-node=' + str(self.job_data['process_count_per_node']))
            f.write('\n')
        if "core_count_per_process" in self.job_data:
            f.write(DIRECTIVE + ' ----cpus-per-task=' + str(self.job_data['core_count_per_process']))
            f.write('\n')
        if "memory_limit" in self.job_data:
            f.write(DIRECTIVE + ' --mem=' + self.job_data['memory_limit'])
            f.write('\n')
        if "minimum_memory_per_processor" in self.job_data:
            f.write(DIRECTIVE + ' --mem-per-cpu=' + self.job_data['minimum_memory_per_processor'])
            f.write('\n')
        if "request_gpus" in self.job_data:
            f.write(DIRECTIVE + ' --gres=gpu:' + str(self.job_data['request_gpus']))
            f.write('\n')
            self.singularity_exec = self.singularity_exec + ' --nv '
        if "request_specific_nodes" in self.job_data:
            f.write(DIRECTIVE + ' --nodelist=' + self.job_data['request_specific_nodes'])
            f.write('\n')
        if "job_array" in self.job_data:
            f.write(DIRECTIVE + ' -a ' + self.job_data['job_array'])
            f.write('\n')
        if "standard_output_file" in self.job_data:
            f.write(DIRECTIVE + ' --output=' + self.job_data['standard_output_file'])
            f.write('\n')
        if "standard_error_file" in self.job_data:
            f.write(DIRECTIVE + ' -error=' + self.job_data['standard_error_file'])
            f.write('\n')
        if "combine_stdout_stderr" in self.job_data:
            pass
        if "architecture_constraint" in self.job_data:
            f.write(DIRECTIVE + ' -C ' + self.job_data['architecture_constraint'])
            f.write('\n')
        if "copy_environment" in self.job_data:
            f.write(DIRECTIVE + ' --export=ALL ')
            f.write('\n')
        if "copy_environment_variable" in self.job_data:
            f.write(DIRECTIVE + ' --export=' + self.job_data['copy_environment_variable'])
            f.write('\n')
        if "job_dependency" in self.job_data:
            f.write(DIRECTIVE + ' --dependency=' + self.job_data['job_dependency'])
            f.write('\n')
        if "request_event_notification" in self.job_data:
            f.write(DIRECTIVE + ' --mail-type=' + self.job_data['request_event_notification'])
            f.write('\n')
        if "email_address" in self.job_data:
            f.write(DIRECTIVE + ' --mail-user=' + self.job_data['email_address'])
            f.write('\n')
        if "defer_job" in self.job_data:
            f.write(DIRECTIVE + ' --begin=' + self.job_data['defer_job'])
            f.write('\n')
        if "node_exclusive" in self.job_data:
            f.write(DIRECTIVE + ' --exclusive')
            f.write('\n')

        f.write('## END OF HEADER ##')
        f.write('\n')
        f.write('cd $SLURM_SUBMIT_DIR')
        f.write('\n')
        self.current_dir = '$SLURM_SUBMIT_DIR/'
        f.write('export PATH=$SLURM_SUBMIT_DIR:$PATH')
        f.write('\n')

        f.close()

    def add_tuner(self):
        __tuner = tuner()
        res = __tuner.encode_tune(self.job_json_obj, self.batch_file)
        if not res:
            logging.warning("Tuning not enabled or Encoding tuner failed")
            return None

        logging.info("Adding tuner" + str(__tuner))
        with open(self.batch_file, 'a') as f:
            f.seek(0, os.SEEK_END)
            f.write('\n')
            f.write('## START OF TUNER ##')
            f.write('\n')
            f.write('file='+__tuner.get_tune_filename())
            f.write('\n')
            f.write('if [ -f $file ] ; then rm $file; fi')
            f.write('\n')
            f.write('wget --no-check-certificate ' + __tuner.get_tune_link())
            f.write('\n')
            f.write('chmod 755 ' + __tuner.get_tune_filename())
            f.write('\n')
            if "container_runtime" in self.app_data:
                cont = self.app_data['container_runtime']
                f.write('\n{} {} {}'.format(self.singularity_exec, self.get_sif_filename(cont), __tuner.get_tune_filename()))
                f.write('\n')
            else:
                f.write('source ' + __tuner.get_tune_filename())
                f.write('\n')
            f.write('## END OF TUNER ##')
            f.write('\n')
            f.close()
            logging.info("Successfully added tuner")

    def add_optscript(self, scriptfile, scriptlink):
        logging.info("Adding optimisations " + scriptfile)
        with open(self.batch_file, 'a') as f:
            f.seek(0, os.SEEK_END)
            f.write('\n')
            f.write('file=' + scriptfile)
            f.write('\n')
            f.write('if [ -f $file ] ; then rm $file; fi')
            f.write('\n')
            f.write('wget --no-check-certificate ' + scriptlink)
            f.write('\n')
            f.write('chmod 755 ' + scriptfile)
            f.write('\n')
            f.write('source ' + scriptfile)
            f.write('\n')
            f.close()
            logging.info("Successfully added optimisation")


    def add_apprun(self):
        logging.info("Adding app run")
        with open(self.batch_file, 'a') as f:
            f.seek(0, os.SEEK_END)
            exe = self.app_data['executable']
            arg = ''
            if "container_runtime" in self.app_data:
                cont = self.app_data['container_runtime']
                cont_exec_command = '{} {} '.format(self.singularity_exec, self.get_sif_filename(cont))
                # f.write('\n{} {} '.format(self.singularity_exec, self.get_sif_filename(cont)))
            else:
                f.write('\n')
            if "arguments" in self.app_data:
                arg = self.app_data['arguments']
            if "app_type" in self.app_data:
                app_type = self.app_data['app_type']
                if "build" in self.app_data:
                    src = self.app_data['build'].get('src')
                    build_command = self.app_data['build'].get('build_command')
                    if src[-4] == '.git':
                        f.write('\ngit clone {}\n'.format(src))
                    else:
                        f.write('\nwget --no-check-certificate {}\n'.format(src))
                    f.write('\n{} {}\n'.format(cont_exec_command, build_command))
                if app_type == 'mpi' or app_type == 'hpc':
                    mpi_ranks = 1
                    threads = 1
                    if "mpi_ranks" in self.app_data:
                        mpi_ranks = self.app_data['mpi_ranks']
                    if "threads" in self.app_data:
                        threads = self.app_data['threads']
                    f.write('\nexport OMP_NUM_THREADS={}\n'.format(threads))
                    if self.scheduler == 'torque' and 'openmpi:1.10' in cont:
                        f.write('{} mpirun -np {} {} {}\n'.format(cont_exec_command, mpi_ranks, exe, arg))
                    elif self.scheduler == 'torque':
                        f.write('mpirun -np {} {} {} {}\n'.format(mpi_ranks, cont_exec_command, exe, arg))
                    elif self.scheduler == 'slurm':
                        f.write('srun -n {} {} {} {}\n'.format(mpi_ranks, cont_exec_command, exe, arg))
                elif app_type == 'python':
                    f.write('{} {} {}\n'.format(cont_exec_command, exe, arg))
            else:
                f.write('\n{} {} {}\n'.format(cont_exec_command, exe, arg))

            f.close()
            logging.info("Successfully added app run")

    def get_sif_filename(self, container: str):
        words = container.split('/')
        return '$SINGULARITY_DIR/' + words[-1].replace(':', '_') + '.sif'

def main():
    dsl_file = "../test/input/tf_snow.json"
    with open(dsl_file) as json_file:
        obj = json.load(json_file)
        gen_t = jobfile_generator(obj, "../test/torque.pbs","torque")
        gen_s = jobfile_generator(obj, "../test/slurm.batch", "slurm")
        gen_t.add_apprun()
        gen_s.add_apprun()

    print(gen_t.get_sif_filename('shub://sodalite-hpe/modak:pytorch-1.5-cpu-pi'))

if __name__ == '__main__':
    main()