## MODAK: START HLRS TESTBED ##
export PATH=/usr/local/bin:$PATH
## MODAK: END HLRS TESTBED ##

