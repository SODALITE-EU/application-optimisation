## MODAK: START HLRS TESTBED ##
module load mpi/openmpi-x86_64
## MODAK: END HLRS TESTBED ##

