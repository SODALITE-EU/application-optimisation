## MODAK: START OF OPT:XLA ##
mkdir xla_dump
export TF_XLA_FLAGS="--tf_xla_auto_jit=2 --tf_xla_cpu_global_jit"
export XLA_FLAGS="--xla_dump_to=xla_dump/generated"
## MODAK: END OF OPT:XLA ##

