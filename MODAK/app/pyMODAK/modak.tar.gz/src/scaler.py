import os,errno
import logging

class scaler():

    def __init__(self):
        logging.info("Initialised MODAK scaler")


def main():
    s = scaler()
    print('Test scaler main')

if __name__ == '__main__':
    main()